############
perimeterPen
############

.. automodule:: fontTools.pens.perimeterPen
   :inherited-members:
   :members:
   :undoc-members:
