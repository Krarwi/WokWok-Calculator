###########
freetypePen
###########

.. automodule:: fontTools.pens.freetypePen
   :inherited-members:
   :members:
   :undoc-members:
