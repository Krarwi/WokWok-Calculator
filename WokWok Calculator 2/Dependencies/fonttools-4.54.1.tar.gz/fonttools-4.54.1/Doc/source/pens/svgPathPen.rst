##########
svgPathPen
##########

.. automodule:: fontTools.pens.svgPathPen
   :inherited-members:
   :members:
   :undoc-members:
