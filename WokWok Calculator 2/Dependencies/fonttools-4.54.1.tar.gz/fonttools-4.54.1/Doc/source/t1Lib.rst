#####
t1Lib
#####

.. automodule:: fontTools.t1Lib
   :inherited-members:
   :members:
   :undoc-members:
