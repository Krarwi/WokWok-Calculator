``GSUB``: Glyph Substitution Table
----------------------------------

.. automodule:: fontTools.ttLib.tables.G_S_U_B_
   :inherited-members:
   :members:
   :undoc-members:

