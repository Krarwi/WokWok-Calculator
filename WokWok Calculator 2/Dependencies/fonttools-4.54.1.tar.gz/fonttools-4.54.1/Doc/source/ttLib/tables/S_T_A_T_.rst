``STAT``: Style Attributes Table
--------------------------------

.. automodule:: fontTools.ttLib.tables.S_T_A_T_
   :inherited-members:
   :members:
   :undoc-members:
