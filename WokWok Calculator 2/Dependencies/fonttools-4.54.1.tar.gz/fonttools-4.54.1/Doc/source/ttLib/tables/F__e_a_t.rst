``Feat``: Graphite Feature Table
--------------------------------

.. automodule:: fontTools.ttLib.tables.F__e_a_t
   :inherited-members:
   :members:
   :undoc-members:


