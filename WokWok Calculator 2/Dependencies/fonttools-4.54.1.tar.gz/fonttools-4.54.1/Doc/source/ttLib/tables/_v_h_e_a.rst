``vhea``: Vertical Header Table
-------------------------------

.. automodule:: fontTools.ttLib.tables._v_h_e_a
   :inherited-members:
   :members:
   :undoc-members:

