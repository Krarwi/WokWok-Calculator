``avar``: Axis Variations Table
-------------------------------

.. automodule:: fontTools.ttLib.tables._a_v_a_r
   :inherited-members:
   :members:
   :undoc-members:

