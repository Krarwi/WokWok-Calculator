``GMAP``: SING Glyphlet Summary Table
-------------------------------------

.. automodule:: fontTools.ttLib.tables.G_M_A_P_
   :inherited-members:
   :members:
   :undoc-members:

