``Silf``: Graphite Rules Table
------------------------------

.. automodule:: fontTools.ttLib.tables.S__i_l_f
   :inherited-members:
   :members:
   :undoc-members:
