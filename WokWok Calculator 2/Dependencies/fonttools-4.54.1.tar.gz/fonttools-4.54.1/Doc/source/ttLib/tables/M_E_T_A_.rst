``META``: SING Glyphlet Metadata Table
--------------------------------------

.. automodule:: fontTools.ttLib.tables.M_E_T_A_
   :inherited-members:
   :members:
   :undoc-members:
