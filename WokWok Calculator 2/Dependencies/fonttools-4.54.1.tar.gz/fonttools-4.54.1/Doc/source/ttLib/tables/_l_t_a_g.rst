``ltag``: Language Tag
----------------------

.. automodule:: fontTools.ttLib.tables._l_t_a_g
   :inherited-members:
   :members:
   :undoc-members:

