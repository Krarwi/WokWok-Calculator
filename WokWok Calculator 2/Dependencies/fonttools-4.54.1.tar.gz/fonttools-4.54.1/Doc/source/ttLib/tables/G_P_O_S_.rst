``GPOS``: Glyph Positioning Table
---------------------------------

.. automodule:: fontTools.ttLib.tables.G_P_O_S_
   :inherited-members:
   :members:
   :undoc-members:

