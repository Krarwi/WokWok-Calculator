``LTSH``: Linear Threshold
--------------------------

.. automodule:: fontTools.ttLib.tables.L_T_S_H_
   :inherited-members:
   :members:
   :undoc-members:

