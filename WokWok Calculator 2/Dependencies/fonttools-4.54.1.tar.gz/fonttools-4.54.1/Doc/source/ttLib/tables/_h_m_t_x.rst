``hmtx``: Horizontal Metrics Table
----------------------------------

.. automodule:: fontTools.ttLib.tables._h_m_t_x
   :inherited-members:
   :members:
   :undoc-members:

