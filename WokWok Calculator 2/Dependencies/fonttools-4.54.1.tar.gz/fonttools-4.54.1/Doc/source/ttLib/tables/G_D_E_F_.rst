``GDEF``: Glyph Definition Table
--------------------------------

.. automodule:: fontTools.ttLib.tables.G_D_E_F_
   :inherited-members:
   :members:
   :undoc-members:

