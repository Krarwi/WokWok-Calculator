``SVG``: SVG (Scalable Vector Graphics) Table
---------------------------------------------

.. automodule:: fontTools.ttLib.tables.S_V_G_
   :inherited-members:
   :members:
   :undoc-members:

