``GPKG``: SING Glyphlet Wrapper Table
-------------------------------------

.. automodule:: fontTools.ttLib.tables.G_P_K_G_
   :inherited-members:
   :members:
   :undoc-members:

