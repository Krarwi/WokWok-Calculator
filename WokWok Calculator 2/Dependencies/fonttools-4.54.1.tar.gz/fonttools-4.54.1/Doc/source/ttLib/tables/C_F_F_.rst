``CFF``: Compact Font Format Table
----------------------------------

.. automodule:: fontTools.ttLib.tables.C_F_F_
   :inherited-members:
   :members:
   :undoc-members:

