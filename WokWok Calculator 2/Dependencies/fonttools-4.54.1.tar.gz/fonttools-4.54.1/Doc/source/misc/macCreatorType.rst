##############################################################
macCreatorType: Functions for working with Mac file attributes
##############################################################

This module requires the `xattr <https://pypi.org/project/xattr/>`_ module
to be installed in order to function correctly.

.. automodule:: fontTools.misc.macCreatorType
   :members:
