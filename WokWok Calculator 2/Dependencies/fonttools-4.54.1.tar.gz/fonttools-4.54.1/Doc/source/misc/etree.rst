#####
etree
#####

.. automodule:: fontTools.misc.etree
   :inherited-members:
   :members:
   :undoc-members: