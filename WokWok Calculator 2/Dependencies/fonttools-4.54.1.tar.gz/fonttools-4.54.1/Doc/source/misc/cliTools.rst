###################################################################
cliTools: Utilities for command-line interfaces and console scripts
###################################################################

.. automodule:: fontTools.misc.cliTools
   :inherited-members:
   :members:
   :undoc-members:
