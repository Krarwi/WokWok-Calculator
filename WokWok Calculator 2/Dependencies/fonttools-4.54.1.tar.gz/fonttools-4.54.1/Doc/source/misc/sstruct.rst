#######
sstruct
#######

.. automodule:: fontTools.misc.sstruct
   :inherited-members:
   :members:
   :undoc-members:
