#########################################
plistlib: Tools for handling .plist files
#########################################

.. automodule:: fontTools.misc.plistlib
   :members: totree, fromtree, load, loads, dump, dumps
