####################################################
bezierTools: Routines for working with Bezier curves
####################################################

.. automodule:: fontTools.misc.bezierTools
   :inherited-members:
   :members:
   :undoc-members:
