###########
unicodedata
###########

.. toctree::
   :maxdepth: 1

   Blocks
   OTTags
   ScriptExtensions
   Scripts

.. automodule:: fontTools.unicodedata
   :inherited-members:
   :members:
   :undoc-members:
