
######
errors
######

.. automodule:: fontTools.ufoLib.errors
   :inherited-members:
   :members:
   :undoc-members:
