
########
plistlib
########

.. automodule:: fontTools.ufoLib.plistlib
   :inherited-members:
   :members:
   :undoc-members:
