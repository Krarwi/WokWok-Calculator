
#####
utils
#####

.. automodule:: fontTools.ufoLib.utils
   :inherited-members:
   :members:
   :undoc-members:
