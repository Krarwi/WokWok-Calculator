###########################
config: configure fontTools
###########################

.. automodule:: fontTools.config
   :inherited-members:
   :members:
   :undoc-members:
