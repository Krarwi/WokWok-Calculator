"""DEPRECATED - This module is kept here only as a backward compatibility shim
for the old ufoLib.pointPen module, which was moved to fontTools.pens.pointPen.
Please use the latter instead.
"""

from fontTools.pens.pointPen import *
