Building the documentation
==========================

The documentation is built using Sphinx and requires, the Read the Docs
theme (`pip install sphinx-rtd-theme`) and the sphinxtabs sphinx extension
(`pip install sphinx-tabs`).
